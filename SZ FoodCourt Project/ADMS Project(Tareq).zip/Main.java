public class Main {
 
    public static void main(String[] args) {
        LibraryManagementSystem x =new LibraryManagementSystem();
        x.setVisible(true);
    }
    
}
